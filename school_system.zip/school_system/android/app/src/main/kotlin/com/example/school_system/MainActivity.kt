package com.example.school_system

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
